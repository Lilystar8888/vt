$(document).ready(function() {
    $("i.icon-icon_choice1_n").click(function() {
        $(this).toggleClass("icon-icon_choice1_n icon-icon_choice1_c")
    });
    $(".zouShi").hover(function() {
        $(this).find("i").toggleClass("icon-icon_datum_n icon-icon_datum_h")
    });
    $(".filter").hover(function() {
        $(".filter-slide").toggleClass("hide unhide");
        event.stopPropagation()
    });

    function a(a, b, c) {
        $(a).click(function() {
            $(b).hide();
            $(c).show()
        })
    }
    a(".ouzhi-pop .show-table .fold-btn", ".show-table", ".show-chart");
    a(".ouzhi-pop .show-chart .fold-btn", ".show-chart", ".show-table");
    a(".ouzhi-pop .content .tab-title .js-btn1", ".show-table", ".show-chart");
    a(".ouzhi-pop .content .tab-title .js-btn2", ".show-chart", ".show-table");
    $(".ouzhi-pop .close-btn").click(function() {
        $(this).parents(".ouzhi-pop").hide()
    });
    $(document).bind("click", function(a) {
        0 == $(a.target).closest(".zhishu-main-content .peilv").length &&
            $(".ouzhi-pop").hide()
    });
    $(".zhishu-main-content .peilv").click(function() {
        $(this).find(".ouzhi-pop").show();
        $(this).parents("tr").siblings("tr").find(".ouzhi-pop").hide()
    })
});