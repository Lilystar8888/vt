$(document).ready(function() {

    $(".go-top").click(function() {
        $("html,body").animate({
            scrollTop: 0
        }, 900)
    });
    var d = function() {
        $("#columnsNav li").sort(function(a, f) {
            return $($(a).data("index")) - $($(f).data("index"))
        }).appendTo($("#columnsNav"));
        var a = $("#columns").children().map(function() {
            return ($(this).is(":visible") ? 1 : -1) * $(this).data("index")
        });
    };
    $("#columns").sortable({
        stop: function() {
            d()
        },
        scrollSensitivity: 10,
        delay: 150,
        axis: "y",
        distance: 10,
        handle: ".title-box",
        create: function(a, c) {
            $("#columns .content-wrap .close").click(function() {
                var a = $(this).parents(".content-wrap"),
                    b = a.index();
                $(".tool-box ul li").eq(b).addClass("disabled");
                a.hide();
                d()
            });
            $(".tool-box ul li").click(function() {
                let index = $(this).data("index");
                $(this).hasClass("nodata")?(
                    null
                ):(
                    $(this).hasClass("disabled") && ($(this).removeClass("disabled"),
                    $(".shuju-main-content .content-wrap").eq(index).show()),
                    $("html, body").animate({
                        scrollTop: $($('a', this).attr('href')).offset().top
                    }, 300),
                    d()
                )
            })
        }
    });
    $(".title-box").on("click", ".go-up", function() {
        var a = $(this).parents(".content-wrap");
        0 < a.prev().size() && (a.prev().before(a), d())
    });
    $(".title-box").on("click", ".go-down", function() {
        var a = $(this).parents(".content-wrap");
        0 < a.next().size() && (a.next().after(a), d())
    });
    $("#recent-saiguo-vsl, #recent-panlu-vsl, #recent-daxiao-vsl, #recent-danshuang-vsl, #recent-saiguo-vsr, #recent-panlu-vsr, #recent-daxiao-vsr, #recent-danshuang-vsr").each(function() {
        var a = $(this).data("percent"),
            c = $(this).data("team");
        $(this).highcharts({
            chart: {
                type: "pie",
                width: 284,
                height: 284,
                renderTo: "histogram",
                defaultSeriesType: "bar",
                backgroundColor: "rgba(255, 255, 255, 0.0)",
                options3d: {
                    enabled: !0,
                    alpha: 5
                }
            },
            title: null,
            colors: ["rgb(241,92,128)", "rgb(131,203,0)", "rgb(124,181,236)"],
            credits: {
                enabled: !1
            },
            exporting: {
                enabled: !1
            },
            plotOptions: {
                pie: {
                    size: 150,
                    allowPointSelect: !0,
                    cursor: "pointer",
                    dataLabels: {
                        enabled: !0,
                        crop: !1,
                        overflow: "none",
                        distance: 5,
                        style: {
                            color: "#333",
                            fontSize: "10px",
                            fontWeight: "500"
                        },
                        formatter: function() {
                            return Highcharts.numberFormat(this.percentage,
                                1) + "% <br> (" + Highcharts.numberFormat(this.y, 0, ",") + this.point.name + ")"
                        }
                    },
                    innerSize: 100,
                    depth: 5
                }
            },
            series: [{
                name: c,
                data: a
            }]
        })
    });
    $(".saiguo-chart, .panlu-chart, .daxiao-chart, .danshuang-chart").attr("class", "saiguo-chart");
    $(".chartinfo").attr("class", "chartinfo");
    $("tspan.highcharts-text-outline").css("fill", "none");
    $("tspan.highcharts-text-outline").css("stroke", "none")
});