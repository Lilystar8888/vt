// JavaScript Document

$(document).ready(function () {

	//侦测各区块隐藏时 右边选单变暗
    $("#columns .content-wrap:hidden").each(function() {
            var t = $(this).data('index')-1;
            $(".tool-box ul li").eq(t).addClass("disabled");
    });

	
	
    //侦测近期战绩主客队显示隐藏 20181019
    var HomeGuest = function(a,b){
        if ($(a).is(":hidden")) {
            $(b).removeClass('hide');
            $(b).click(function() {
                $(a).toggleClass('hide');
                $(b).toggleClass('active');
            });
        }
    };
	
    HomeGuest(rvsl,vslb),
    HomeGuest(rvsr,vsrb);
	
	
	//侦测近期战绩主客队显示隐藏 20170904
	var rvsl = $('.shuju-main-content .recent-compet .recent-content .vsl-content');
	var rvsr = $('.shuju-main-content .recent-compet .recent-content .vsr-content');
	var vslb = $('.shuju-main-content .title-box .func-btn-wrap .showvsl');
	var vsrb = $('.shuju-main-content .title-box .func-btn-wrap .showvsr');


	var ctvsl1 = $("#recent-saiguo-vsl").highcharts();
	var ctvsl2 = $("#recent-panlu-vsl").highcharts();
	var ctvsl3 = $("#recent-daxiao-vsl").highcharts();
	var ctvsl4 = $("#recent-danshuang-vsl").highcharts();
	
	var ctvsr1 = $("#recent-saiguo-vsr").highcharts();
	var ctvsr2 = $("#recent-panlu-vsr").highcharts();
	var ctvsr3 = $("#recent-daxiao-vsr").highcharts();
	var ctvsr4 = $("#recent-danshuang-vsr").highcharts();

	//以往盘路（上盘场数）大者加粗
	var vslq1 = $('#vslq1').text();
	var vsrq1 = $('#vsrq1').text();
	if(vslq1>vsrq1){$('#vsl1').addClass('highlight');}else{$('#vsr1').addClass('highlight');}
	
	//以往盘路（下盘场数）大者加粗
	var vslq2 = $('#vslq2').text();
	var vsrq2 = $('#vsrq2').text();
	if(vslq2>vsrq2){$('#vsl2').addClass('highlight');}else{$('#vsr2').addClass('highlight');}
	
	//使上一场阵容左右表格等高
	 var height = 0;
     $('tr.zhenrongl, tr.zhenrongr').each(function(){
        height = $(this).height() > height ? $(this).height() : height;
     }).height(height+50);

	//20171218
	var vhk = $('.shuju-main-content .history-compet .history-info div .title').width();
	$('.shuju-main-content .history-compet .history-info div .title.empty').css('width',vhk);

	var vhl = $('.vsl-content .chartwrap .chartinfo div .title').width();
	$('.vsl-content .chartwrap .chartinfo div .title.empty').css('width',vhl);

	var vhr = $('.vsr-content .chartwrap .chartinfo div .title').width();
	$('.vsr-content .chartwrap .chartinfo div .title.empty').css('width',vhr);

	
    //全部赛事 & 5场 & 赛事筛选 滑动开启选单 20170731
	$('.all-compet, .changci, .choose-compet, .fullhalf')
		.mouseenter(function() {$(this).find('.choose-wrap-slide').removeClass('hide').addClass('unhide');})
		.mouseleave(function() {$(this).find('.choose-wrap-slide').removeClass('unhide').addClass('hide');});
	
    //欧洲指数 滑动开启选单  20170731
	$('.history-compet .ouzhi')
		.mouseenter(function() {$('.history-compet .ouzhi .ouzhi-slide').removeClass('hide').addClass('unhide');})
		.mouseleave(function() {$('.history-compet .ouzhi .ouzhi-slide').removeClass('unhide').addClass('hide');}); 

	//欧洲指数 滑动开启选单  20170830
	$('.recent-compet .vsl-content .ouzhi')
		.mouseenter(function() {$('.recent-compet .vsl-content .ouzhi .ouzhi-slide').removeClass('hide').addClass('unhide');})
		.mouseleave(function() {$('.recent-compet .vsl-content .ouzhi .ouzhi-slide').removeClass('unhide').addClass('hide');}); 

	$('.recent-compet .vsr-content .ouzhi')
		.mouseenter(function() {$('.recent-compet .vsr-content .ouzhi .ouzhi-slide').removeClass('hide').addClass('unhide');})
		.mouseleave(function() {$('.recent-compet .vsr-content .ouzhi .ouzhi-slide').removeClass('unhide').addClass('hide');}); 



    //亚洲盘口 滑动开启选单 点选关闭选单 20170731
	$('.history-compet .zhongpan')
		.mouseenter(function() {$('.history-compet .zhongpan .ouzhi-slide').removeClass('hide').addClass('unhide');})
		.mouseleave(function() {$('.history-compet .zhongpan .ouzhi-slide').removeClass('unhide').addClass('hide');}); 

	$('.recent-compet .vsl-content .zhongpan')
		.mouseenter(function() {$('.recent-compet .vsl-content .zhongpan .ouzhi-slide').removeClass('hide').addClass('unhide');})
		.mouseleave(function() {$('.recent-compet .vsl-content .zhongpan .ouzhi-slide').removeClass('unhide').addClass('hide');}); 

	$('.recent-compet .vsr-content .zhongpan')
		.mouseenter(function() {$('.recent-compet .vsr-content .zhongpan .ouzhi-slide').removeClass('hide').addClass('unhide');})
		.mouseleave(function() {$('.recent-compet .vsr-content .zhongpan .ouzhi-slide').removeClass('unhide').addClass('hide');}); 

	//点选关闭选单  20170731
	$('.choose-wrap-slide, .ouzhi .ouzhi-slide, .zhongpan .ouzhi-slide').click(function(e) {e.preventDefault();$(this).removeClass('unhide').addClass('hide');});

	
	
	


	
	
	//切换选项标题
	$('.choose-wrap-slide ul li').on('click', function(){
		var showtext = $(this).html();
		$(this).parent().parent().parent().parent().find('span').text(showtext);
	});
	
	
	//历史交锋 只显示最近5 10 15场
    $('table.recent-rival > tbody > tr, table.team-recent-match > tbody > tr').not('.no-record').hide().slice(0, 5).show();
    $('#jiaofeng .changci ul li').on('click', function(){
        var showrow = $(this).data('value');
		var showtext = $(this).html();
        $('table.recent-rival > tbody > tr').not('.no-record').hide().slice(0, showrow).show();
		$('#shengfu .changci span').text(showtext);
	});
	
    //近期战绩左队 只显示最近5 10 15场
    $('.vsl-content table.team-recent-match > tbody > tr').not('.no-record').hide().slice(0, 5).show();
    $('#zhanji .vsl-content .changci ul li').on('click', function(){
        var showrow = $(this).data('value');
		var showtext = $(this).html();
        $('.vsl-content table.team-recent-match > tbody > tr').not('.no-record').hide().slice(0, showrow).show();
		$('#zhanji .vsl-content .changci span').text(showtext);
    });

    //近期战绩右队 只显示最近5 10 15场
    $('.vsr-content table.team-recent-match > tbody > tr').not('.no-record').hide().slice(0, 5).show();
    $('#zhanji .vsr-content .changci ul li').on('click', function(){
        var showrow = $(this).data('value');
		var showtext = $(this).html();
        $('.vsr-content table.team-recent-match > tbody > tr').not('.no-record').hide().slice(0, showrow).show();
		$('#zhanji .vsr-content .changci span').text(showtext);
    });	
	
}); //最後的括號勿刪除