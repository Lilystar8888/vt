$(document).ready(function() {
    var wh = $(window).height();
    $(document).height() > wh && $(window).scroll(function() {
        0 < $(window).scrollTop() ? $(".wc-nav-info").addClass("sticky") : $(".wc-nav-info").removeClass("sticky")
    });
    $(".js-competSlide").click(function() {
        $("#choose-compet").toggleClass("hide unhide");
        $("#choose-compet").addClass("animated fadeIn");
        event.stopPropagation()
    });
    $(".compet-name").closest("li").click(function() {
        $(this).find("i").toggleClass("icon-icon_choice_c icon-icon_choice_n");
        event.stopPropagation()
    });
    $(".choose-all").click(function() {
        $("#choose-compet").find("i.icon-icon_choice_n").removeClass("icon-icon_choice_n").addClass("icon-icon_choice_c");
        event.stopPropagation()
    });
    $(".back-choose").click(function() {
        $("#choose-compet").find("i").toggleClass("icon-icon_choice_c icon-icon_choice_n");
        event.stopPropagation()
    });
    $(".five-compet").click(function() {
        $(this).parent().parent().parent().find("i.icon-icon_choice_c").removeClass("icon-icon_choice_c").addClass("icon-icon_choice_n");
        var a = ["\u5fb7\u7532", "\u610f\u7532", "\u6cd5\u7532", "\u897f\u7532", "\u82f1\u8d85"];
        $("span").each(function() {
            var b = $(this);
            a.forEach(function(a) {
                -1 < b.text().indexOf(a) &&
                    b.closest("li").find("i").removeClass("icon-icon_choice_n").addClass("icon-icon_choice_c")
            })
        });
        event.stopPropagation()
    });
    $(".prem-compet").click(function() {
        $(this).parent().parent().parent().find("i.icon-icon_choice_c").removeClass("icon-icon_choice_c").addClass("icon-icon_choice_n");
        var a = "\u963f\u7532 \u5fb7\u7532 \u6cd5\u56fd\u676f \u56fd\u9645\u53cb\u8c0a \u8377\u7532 \u5357\u7403\u676f \u5357\u7f8e\u8d85\u676f \u8461\u676f \u82cf\u8d85 \u897f\u7532 \u82f1\u8d85 \u610f\u5927\u5229\u676f".split(" ");
        $("span").each(function() {
            var b = $(this);
            a.forEach(function(a) {
                -1 < b.text().indexOf(a) && b.closest("li").find("i").removeClass("icon-icon_choice_n").addClass("icon-icon_choice_c")
            })
        });
        event.stopPropagation()
    });
    $(document).on("click", function() {
        $("#choose-compet").removeClass("unhide").addClass("hide")
    });
    $("i.icon-btn_collect_n").click(function() {
        $(this).toggleClass("icon-btn_collect_c")
    })
});