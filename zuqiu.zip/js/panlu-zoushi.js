$(document).ready(function() {
    var a = function(b, c) {
            c || (c = window.location.href);
            b = b.replace(/[\[\]]/g, "\\$&");
            var a = (new RegExp("[?&]" + b + "(=([^&#]*)|&|#|$)")).exec(c);
            return a ? a[2] ? decodeURIComponent(a[2].replace(/\+/g, " ")) : "" : null
        }("tab"),
        b = $(".asia");
    "asia" === a ? (b = $(".asia"),$("#asia").addClass("active").siblings("li").removeClass("active")) :
    "euro" === a ? (b = $(".euro"), $("#euro").addClass("active").siblings("li").removeClass("active")) :
    "size" === a ? (b = $(".size"), $("#size").addClass("active").siblings("li").removeClass("active")) :
    "sanheyi" === a && (b = $(".sanheyi"), $("#sanheyi").addClass("active").siblings("li").removeClass("active"));
    b.removeClass("hide").siblings("div").not(".tab-title").addClass("hide");
    window.scrollTo(0, 100);
    a = $(".scroe-wrap .vsleft").text();
    b = $(".scroe-wrap .vsright").text();
    a > b ? $(".info-banner .score .scroe-wrap").addClass("leftwin") :
        $(".info-banner .score .scroe-wrap").addClass("rightwin");
    $(".main-content .tab-title li").click(function(e) {
        var b = e.target.id,
            a = "";
        "asia" === b ? a = $(".asia") :
        "euro" === b ? a = $(".euro") :
        "size" === b ? a = $(".size") :
        "sanheyi" === b && (a = $(".sanheyi"));
        $(".main-content .tab-title li").removeClass("active");
        $(this).addClass("active").siblings("li").removeClass("active");
        a.removeClass("hide").siblings("div").not(".tab-title").addClass("hide");
    })
});
