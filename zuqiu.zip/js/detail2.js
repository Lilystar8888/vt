//切换到视频
function openvideo() {
    $("#watch-anima, .animation-content").removeClass("current");
    $("#watch-video, .video-content").addClass("current")
}

//切换到动画
function openanima() {
    $("#watch-video, .video-content").removeClass("current");
    $("#watch-anima, .animation-content").addClass("current")
}

$(document).ready(function() {
    //解析网址后跟的tab
    var a = function(a, b) {
            b || (b = window.location.href);
            a = a.replace(/[\[\]]/g, "\\$&");
            var c = (new RegExp("[?&]" + a + "(=([^&#]*)|&|#|$)")).exec(b);
            return c ? c[2] ? decodeURIComponent(c[2].replace(/\+/g, " ")) : "" : null
        }("tab"),
        b = "";
    $(".watch-live .link, .content").removeClass("current");
    "stream" === a ? (
        b = $(".video-content"), $(".watch-live #watch-video").addClass("current")
    ) : (
        b = $(".animation-content"), $(".watch-live #watch-anima").addClass("current")
    );

    b.addClass("current").siblings().removeClass("current");

    //切换线路
    $(".video-panel>a").click(function() {
        $(this).addClass("active").siblings().removeClass("active")
    });

    //会员专属
    $(".ssmbonly").click(function() {
        $(".login-sign-box, #loginBox").removeClass("hide");
        $(".exit-login").addClass("hide")
    });

});

//20191212 紀錄lightbox已开启
$(document).on('lity:open', function(event, instance) {
    $("body").addClass("lity-opened");
});

//20191212 紀錄lightbox已关闭
$(document).on('lity:close', function(event, instance) {
    $("body").removeClass("lity-opened");
});