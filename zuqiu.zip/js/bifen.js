$(document).ready(function() {
    //即时进球通知-点击关闭
    $(".football-tip-goal .icon-close").click(function() {
        $(".football-tip-goal .icon-close").addClass("hide");
        $(".football-tip-goal .fide-item").addClass("goout")
    });
    //今日无五大联赛-点击关闭
    $("#nofivecompets").click(function() {
        $(this).addClass("hide")
    });
    //往下卷固定表头
    var g = $(window).height();
    $(document).height() > g && $(window).scroll(function() {
        $(window).scrollTop()>216 ?
        $("#bf-nav-info").addClass("sticky"):
        $("#bf-nav-info").removeClass("sticky")
    });
    //竞彩,北单,足彩,完整
    $("#jingcai, #beidan, #zucai, #wanzheng").click(function() {
        $(this).addClass("active").siblings().removeClass("active")
    });
    var f = $("#showCompany");
        b = $("#choose-company");
        g = $("#showcompet"),
        c = $("#choose-compet"),
        p = $("#showpankou"),
        d = $("#choose-pankou"),
        h = $("#showpankou1"),
        k = $("#showpankou2"),
        l = $("#pankou1"),
        n = $("#pankou2"),
        q = $(".js-voiceSlide"),
        e = $("#sound-slide"),
        r = $(".js-set-btn"),
        m = $(".set-wrap"),
        t = $(".set-content");
    f.click(function() {
        b.toggleClass("hide");
        e.addClass("hide");
        c.addClass("hide");
        d.addClass("hide");
        event.stopPropagation()
    });
    g.click(function() {
        c.toggleClass("hide");
        e.addClass("hide");
        b.addClass("hide");
        d.addClass("hide");
        event.stopPropagation()
    });
    p.click(function() {
        d.toggleClass("hide");
        e.addClass("hide");
        b.addClass("hide");
        c.addClass("hide");
        event.stopPropagation()
    });
    h.click(function() {
        l.removeClass("hide").addClass("active");
        n.addClass("hide").removeClass("active");
        k.removeClass("active");
        h.addClass("active");
        event.stopPropagation()
    });
    k.click(function() {
        l.removeClass("hide");
        n.removeClass("hide").addClass("active");
        l.addClass("hide").removeClass("active");
        h.removeClass("active");
        k.addClass("active");
        event.stopPropagation()
    });
    $(".compet-name").closest("li").click(function() {
        $(this).find("i").toggleClass("icon-icon_choice_c icon-icon_choice_n");
        event.stopPropagation()
    });
    $(".choose, .cancel").click(function() {
        $(this).parent().parent().parent().addClass("hide");
        event.stopPropagation()
    });
    $(".five-compet").click(function() {});
    $(".prem-compet").click(function() {});
    $("#choose-mode li a.first").hover(function() {
        $(this).parent().parent().parent().find("i").toggleClass("active")
    });
    $("#choose-company li:first-child").click(function() {
        $(this).addClass("active").siblings("").removeClass("active");
        $("#choose-company .icon-w-arrow").addClass("active");
        var a = $(this).text();
        $("#showCompany span").text(a);
        b.toggleClass("hide")
    });
    $("#choose-company li:not(:first-child)").click(function() {
        $(this).addClass("active").siblings("").removeClass("active");
        $("#choose-company .icon-w-arrow").removeClass("active");
        var a = $(this).text();
        $("#showCompany span").text(a);
        b.toggleClass("hide")
    });
    $("#choose-company>ul>li>a.en").click(function() {
        $("#showCompany span").addClass("en")
    });
    $("#choose-company>ul>li>a:not(.en)").click(function() {
        $("#showCompany span").removeClass("en")
    });
    $("#choose-company li:first-child").not(".active").hover(function() {
        $("#choose-company .icon-w-arrow").toggleClass("active")
    });
    q.click(function() {
        e.toggleClass("hide");
        b.addClass("hide");
        c.addClass("hide");
        d.addClass("hide");
        event.stopPropagation()
    });
    $("#sound-slide li").click(function() {
        var txt = $(this).text();
        $(".js-voiceSlide>a>span").text(txt);
        $(this).addClass("sound-chosen").siblings().removeClass("sound-chosen");
    });
    $("#sound-slide li.first").hover(function() {
        $("#sound-slide .icon-w-arrow").toggleClass("active")
    });
    r.click(function() {
        m.toggleClass("hide");
        e.addClass("hide");
        b.addClass("hide");
        c.addClass("hide");
        d.addClass("hide");
        event.stopPropagation()
    });
    $(document).on("click", function() {
        e.addClass("hide");
        b.addClass("hide");
        c.addClass("hide");
        d.addClass("hide");
        m.addClass("hide")
    });
    b.on("click", function(a) {
        a.stopPropagation()
    });
    c.on("click", function(a) {
        a.stopPropagation()
    });
    d.on("click", function(a) {
        a.stopPropagation()
    });
    t.click(function() {
        event.stopPropagation()
    });
    $("i.icon-btn_top_n").click(function() {
        $(this).toggleClass("icon-btn_top_c")
    });
    $("i.icon-btn_collect_n").click(function() {
        $(this).toggleClass("icon-btn_collect_c")
    });
    $("#chooseAll").click(function() {
        $(".container").find("i.icon-icon_choice_n").toggleClass("icon-icon_choice_c")
    });
    $("i.icon-icon_choice_c").click(function() {
        $(this).toggleClass("icon-icon_choice_c icon-icon_choice_n");
        event.stopPropagation()
    });
    $("i.icon-icon_choice_n").click(function() {
        $(this).toggleClass("icon-icon_choice_c icon-icon_choice_n");
        event.stopPropagation()
    });
    $(".icon-set-close").click(function() {
        m.toggleClass("hide");
        event.stopPropagation()
    });
    $(".choose-btn span").click(function() {
        $(this).parent().find("span").removeClass("current");
        $(this).addClass("current");
        event.stopPropagation()
    });
    $(".choose-card span.on").click(function() {
        $(".yellow-warn").css("display", "inline");
        $(".red-warn").css("display",
            "inline")
    });
    $(".choose-card span.off").click(function() {
        $(".yellow-warn").css("display", "none");
        $(".red-warn").css("display", "none")
    });
    $(".choose-hide span.on").click(function() {
        $(".rank").css("display", "inline")
    });
    $(".choose-hide span.on").click(function() {
        $(".rank").css("display", "none")
    });
    $(".choose-light span.off").click(function() {
        $("body").css("background-color", "#2b2b2b");
        $(".bf-content").css("background-color", "#e1e1e1");
        $("nav").css("display", "none");
        $("#ssCarousel").css("display", "none");
        $("#ssCarousel").toggleClass("lighton lightoff");
        $(".parallelogram").css("display", "none");
        $("#bshareF").css("display", "none")
    });
    $(".choose-light span.on").click(function() {
        $("body").css("background-color", "#e1e1e1");
        $("nav").css("display", "block");
        $("#ssCarousel").css("display", "block");
        $("#ssCarousel").toggleClass("lighton lightoff");
        $(".parallelogram").css("display", "block");
        $("#bshareF").css("display", "block")
    });
    $(".tr-sb").hover(function() {
        $(this).find(".sbTooltip").toggleClass("hide")
    });
    $(".tr-vs-score").hover(function() {
        $(this).find(".bifen-tooltip").toggleClass("hide")
    });
    $(".close-col").click(function() {
        $(".my-collection").toggleClass("hide")
    })
});