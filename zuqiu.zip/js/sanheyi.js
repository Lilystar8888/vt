$(document).ready(function() {
    $(".zouShi").hover(function() {
        $(this).find("i").toggleClass("icon-icon_datum_n icon-icon_datum_h")
    });
    $(".toggle-first").click(function() {
        $(this).find("i").toggleClass("icon-icon_choice_c icon-icon_choice_n");
        $(".zhishu-main-content table tbody tr td .first").toggleClass("hide unhide");
        event.stopPropagation()
    });
});