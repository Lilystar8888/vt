import MDBTableEditor from "@/components/MDBTableEditor";

export { MDBTableEditor };
