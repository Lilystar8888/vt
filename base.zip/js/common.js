var isMobile = {Android: function() { return navigator.userAgent.match(/Android/i) }, BlackBerry: function() { return navigator.userAgent.match(/BlackBerry/i) }, iOS: function() { return navigator.userAgent.match(/iPhone|iPad|iPod/i) }, Opera: function() { return navigator.userAgent.match(/Opera Mini/i) }, Windows: function() { return navigator.userAgent.match(/IEMobile/i) }, any: function() { return isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows() } };

//跑马灯
function slideLine(box, stf, delay, speed, h) {
    var slideBox = document.getElementById(box);
    //console.log(slideBox);
    var delay = delay || 5600,
        speed = speed || 20,
        h = h || 20;
    var tid = null,
        pause = false;
    var s = function() { tid = setInterval(slide, speed); }
    var slide = function() {
        if (pause) return;
        slideBox.scrollTop += 1;
        if (slideBox.scrollTop % h == 0) {
            clearInterval(tid);
            slideBox.appendChild(slideBox.getElementsByTagName(stf)[0]);
            slideBox.scrollTop = 0;
            setTimeout(s, delay);
        }
    }
    if (slideBox) {
        slideBox.onmouseover = function() { pause = true; }
        slideBox.onmouseout = function() { pause = false; }
        setTimeout(s, delay);
    }
}

//跑马灯2 聊天室主播专用
function slideLine2(box, stf) {
    var slideBox = document.getElementById(box);
    //console.log(stf);
    var lastBox = stf.length-1;
    //console.log('lastBox:'+lastBox);
    var delay = 2000;
    var speed = 8000,
        h = 20;
    var tid = null,
        pause = false,
        i = -1;
    var s = function() { tid = setInterval(slide, speed); }
    var slide = function() {
        if (pause) return;
        i+= 1;
        if(i > lastBox) {
            i = 0;
        }
        console.log('i='+i);
        let thisbox = stf[i];
        let thislength = thisbox.length;

        if(thislength>10){
            slideBox.className = 'long';
            slideBox.innerHTML = '<div class="longtxt">'+thisbox+'</div>';
        }else{
            slideBox.className = 'short';
            // slideBox.innerHTML = '<div class="ann">'+thisbox+'</div>';
            let nextbox = stf[i+1];
            if(nextbox){
                let nextlength = nextbox.length;
                console.log('nextlength:'+nextlength);
                if(nextlength<11) {
                    slideBox.innerHTML ='<div class="ann"><span>'+thisbox+'</span><span>'+nextbox+'</div>';
                }
            }else{
                slideBox.innerHTML = '<div class="ann">'+thisbox+'</div>';
            }
        }
    }
    if (slideBox) {
        slideBox.onmouseover = function() { pause = true; }
        slideBox.onmouseout = function() { pause = false; }
        //console.log('delay'+delay);
        setTimeout(s, delay);
    }
}

//取得URL参数
function getParameterByName(a) {
    a = a.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    a = (new RegExp("[\\?&]" + a + "=([^&#]*)")).exec(location.search);
    return null == a ? "" : decodeURIComponent(a[1])
}

//返回顶部
function goTop() {
    $("html,body").animate({
        scrollTop: 0
    }, 300)
}

//20200603 显示提示色块后自订秒数自动消失
function openSmartTip(a, t) {
    $(a).addClass('show');
    var SmartTipClock = window.setTimeout((() => $(a).removeClass('show')), t);
}

//20200603 多语系切换
function multiLingual(t, a, e) {
    $(t).addClass('active').siblings('li').removeClass('active');
    //显示提示色块"加载中"" 自订秒数a后自动消失
    openSmartTip('.ssloader', a);
}

//开启关闭意见反馈
function feedbackOpen() {
    $(".feedback-wrap").toggleClass("hide")
}

//关闭意见反馈
function feedbackClose() {
    $(".forms-ok").addClass("hide");
    $(".feedback-wrap").addClass("hide");
    $(".feedback-box").removeClass("hide")
}

function feedbackSwitch(t,e) {
    $(t).addClass("current").siblings("span").removeClass("current");
    e.stopPropagation();
}

//提交反馈
function feedbackSend() {
    $(".feedback-form").addClass("hide");
    $(".forms-ok").removeClass("hide");
    setTimeout(function() {
        feedbackClose()
    }, 3E3);
}

//隐藏美女主播视窗
function closeZhubo() {
    $(".zhubo-tab").css("opacity",'1'),
    $(".zhubo-content").hide('fade');
}

//显示美女主播视窗
function showZhubo() {
    $('.zhubo-tab, .zhubo-content').bind('click', function(){
        if($(this).data('dragging')) return;
        $(".zhubo-tab").css("opacity",'0'),
        $(".zhubo-content").show()
    });
}

//美女主播视窗音量控制
function volumeControl() {
    var a = $("#zhuboPlayer");
    $("#volume-control").find(".svgbtn").toggleClass("hide");
    a[0].contentWindow.toggleVolume()
}

$(document).ready(function() {
    $('[class^="icon-btn"]').click(function() {
        $(this).toggleClass("selected")
    });
})