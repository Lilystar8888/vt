$(document).ready(function() {
    $("#XCarousel").carousel();
    $(".tab-title li").click(function() {
        event.preventDefault();
        $(this).addClass("active").siblings("li").removeClass("active");
        var a = $(this).index() - 1;
        console.log(a);
        $(".tab-content").eq(a).removeClass("hide").siblings(".tab-content").addClass("hide");
    });
});