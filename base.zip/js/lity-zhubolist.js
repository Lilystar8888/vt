(function(g, c) {
    "function" === typeof define && define.amd ? define(["jquery"], function(q) {
        return c(g, q)
    }) : "object" === typeof module && "object" === typeof module.exports ? module.exports = c(g, require("jquery")) : g.lity = c(g, g.jQuery || g.Zepto)
})("undefined" !== typeof window ? window : this, function(g, c) {
    function q(a) {
        var b = v();
        z && a.length ? (a.one(z, b.resolve), setTimeout(b.resolve, 500)) : b.resolve();
        return b.promise()
    }

    function r(a, b, d) {
        if (1 === arguments.length) return c.extend({}, a);
        if ("string" === typeof b) {
            if ("undefined" ===
                typeof d) return "undefined" === typeof a[b] ? null : a[b];
            a[b] = d
        } else c.extend(a, b);
        return this
    }

    function w(a) {
        a = decodeURI(a.split("#")[0]).split("&");
        for (var b = {}, c, f = 0, e = a.length; f < e; f++) a[f] && (c = a[f].split("="), b[c[0]] = c[1]);
        return b
    }

    function t(a, b) {
        return a + (-1 < a.indexOf("?") ? "&" : "?") + c.param(b)
    }

    function u(a, b) {
        var c = a.indexOf("#");
        if (-1 === c) return b;
        0 < c && (a = a.substr(c));
        return b + a
    }

    function A(a, b) {
        var d = b.opener() && b.opener().data("lity-desc") || "Image with no description",
            f = c('<img src="' + a + '" alt="' +
                d + '"/>'),
            e = v(),
            m = function() {
                e.reject(c('<span class="lity-error"/>').append("Failed loading image"))
            };
        f.on("load", function() {
            if (0 === this.naturalWidth) return m();
            e.resolve(f)
        }).on("error", m);
        return e.promise()
    }

    function p(a) {
        return '<div class="lity-iframe-container"><iframe frameborder="0" allowfullscreen src="' + a + '"/></div>';
    }

    function B() {
        return n.documentElement.clientHeight ? n.documentElement.clientHeight : Math.round(x.height())
    }

    function C(a) {
        var b = D();
        if (b && (27 === a.keyCode && b.close(), 9 === a.keyCode)) {
            b =
                b.element().find('a[href],area[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),button:not([disabled]),iframe,object,embed,[contenteditable],[tabindex]:not([tabindex^="-"])');
            var c = b.index(n.activeElement);
            a.shiftKey && 0 >= c ? (b.get(b.length - 1).focus(), a.preventDefault()) : a.shiftKey || c !== b.length - 1 || (b.get(0).focus(), a.preventDefault())
        }
    }

    function E() {
        c.each(k, function(a, b) {
            b.resize()
        })
    }

    function G(a) {
        1 === k.unshift(a) && (F.addClass("lity-active"),x.on({
            resize: E,
            keydown: C
        }));
        c("body > *").not(a.element()).addClass("lity-hidden").each(function() {
            var b =
                c(this);
            void 0 === b.data("lity-aria-hidden") && b.data("lity-aria-hidden", b.attr("aria-hidden") || null)
        }).attr("aria-hidden", "true")
    }

    function H(a) {
        a.element().attr("aria-hidden", "true");
        1 === k.length && (F.removeClass("lity-active"), x.off({
            resize: E,
            keydown: C
        }));
        k = c.grep(k, function(b) {
            return a !== b
        });
        (k.length ? k[0].element() : c(".lity-hidden")).removeClass("lity-hidden").each(function() {
            var b = c(this),
                a = b.data("lity-aria-hidden");
            a ? b.attr("aria-hidden", a) : b.removeAttr("aria-hidden");
            b.removeData("lity-aria-hidden")
        })
    }

    function D() {
        return 0 === k.length ? null : k[0]
    }

    function I(a, b, d, f) {
        var e = "inline",
            m = c.extend({}, d);
        if (f && m[f]) {
            var g = m[f](a, b);
            e = f
        } else c.each(["inline", "iframe"], function(b, a) {
            delete m[a];
            m[a] = d[a]
        }), c.each(m, function(c, d) {
            if (!d || d.test && !d.test(a, b)) return !0;
            g = d(a, b);
            if (!1 !== g) return e = c, !1
        });
        return {
            handler: e,
            content: g || ""
        }
    }

    function J(a, b, d, f) {
        var e = this,
            g = !1,
            k = !1,
            h;
        b = c.extend({}, y, b);
        var l = c(b.template);
        e.element = function() {
            return l
        };
        e.opener = function() {
            return d
        };
        e.options = c.proxy(r, e, b);
        e.handlers =
            c.proxy(r, e, b.handlers);
        e.resize = function() {
            g && !k && h.css("max-height", B() + "px").trigger("lity:resize", [e])
        };
        e.close = function() {
            if (g && !k) {
                k = !0;
                H(e);
                var a = v();
                if (f && (n.activeElement === l[0] || c.contains(l[0], n.activeElement))) try {
                    f.focus()
                } catch (P) {}
                h.trigger("lity:close", [e]);
                l.removeClass("lity-opened").addClass("lity-closed");
                q(h.add(l)).always(function() {
                    h.trigger("lity:remove", [e]);
                    l.remove();
                    l = void 0;
                    a.resolve()
                });
                return a.promise()
            }
        };
        a = I(a, e, b.handlers, b.handler);
        if(document.body.classList.contains('lity-opened')===false){
            l.attr("aria-hidden", "false").addClass("lity-loading lity-opened lity-" +
                a.handler).appendTo("body").focus().on("click", "[data-lity-close]", function(a) {
                c(a.target).is("[data-lity-close]") && (e.close(),
                c(".prepended").remove(), c(".appended").remove(),
                c(".videobox").removeClass("active"))
            }).trigger("lity:open", [e]);
            G(e);
            c.when(a.content).always(function(a) {
                h = c(a).css("max-height", B() + "px");
                l.find(".lity-loader").each(function() {
                    var a = c(this);
                    q(a).always(function() {
                        a.remove()
                    })
                });
                l.removeClass("lity-loading").find(".lity-content").empty().append(h);
                g = !0;
                h.trigger("lity:ready",[e])
            })
        }
    }

    function h(a, b, d) {
        a.preventDefault ? (a.preventDefault(), d = c(this), a = d.data("lity-target") || d.attr("href") || d.attr("src")) : d = c(d);
        b = new J(a, c.extend({}, d.data("lity-options") || d.data("lity"), b), d, n.activeElement);
        if (!a.preventDefault) return b
    }
    var n = g.document,
        x = c(g),
        v = c.Deferred,
        F = c("html"),
        BODY = c("body"),
        k = [],
        y = {
            handler: null,
            handlers: {
                image: A,
                inline: function(a, b) {
                    try {
                        var d = c(a)
                    } catch (m) {
                        return !1
                    }
                    if (!d.length) return !1;
                    var f = c('<i style="display:none !important"/>');
                    var e = d.hasClass("lity-hide");
                    b.element().one("lity:remove",
                        function() {
                            f.before(d).remove();
                            e && !d.closest(".lity-content").length && d.addClass("lity-hide")
                        });
                    return d.removeClass("lity-hide").after(f)
                },
                youtube: function(a) {
                    var b = K.exec(a);
                    return b ? p(u(a, t("https://www.youtube" + (b[2] || "") + ".com/embed/" + b[4], c.extend({
                        autoplay: 1
                    }, w(b[5] || ""))))) : !1
                },
                vimeo: function(a) {
                    var b = L.exec(a);
                    return b ? p(u(a, t("https://player.vimeo.com/video/" + b[3], c.extend({
                        autoplay: 1
                    }, w(b[4] || ""))))) : !1
                },
                googlemaps: function(a) {
                    var b = M.exec(a);
                    return b ? p(u(a, t("https://www.google." + b[3] +
                        "/maps?" + b[6], {
                            output: 0 < b[6].indexOf("layer=c") ? "svembed" : "embed"
                        }))) : !1
                },
                facebookvideo: function(a) {
                    var b = N.exec(a);
                    if (!b) return !1;
                    0 !== a.indexOf("http") && (a = "https:" + a);
                    return p(u(a, t("https://www.facebook.com/plugins/video.php?href=" + a, c.extend({
                        autoplay: 1
                    }, w(b[4] || "")))))
                },
                iframe: p
            },
            template: '<div class="lity" role="dialog" aria-label="Dialog Window (Press escape to close)" tabindex="-1"><div class="lity-wrap" role="document"><div class="lity-loader" aria-hidden="true">加载中...</div><div class="lity-container"><div class="lity-content"></div><button class="lity-close" type="button" aria-label="Close (Press escape to close)" data-lity-close>&times;</button></div></div></div>'
        },
        O = /(^data:image\/)|(\.(png|jpe?g|gif|svg|webp|bmp|ico|tiff?)(\?\S*)?$)/i,
        K = /(youtube(-nocookie)?\.com|youtu\.be)\/(watch\?v=|v\/|u\/|embed\/?)?([\w-]{11})(.*)?/i,
        L = /(vimeo(pro)?.com)\/(?:[^\d]+)?(\d+)\??(.*)?$/,
        M = /((maps|www)\.)?google\.([^\/\?]+)\/?((maps\/?)?\?)(.*)/i,
        N = /(facebook\.com)\/([a-z0-9_-]*)\/videos\/([0-9]*)(.*)?$/i,
        z = function() {
            var a = n.createElement("div"),
                b = {
                    WebkitTransition: "webkitTransitionEnd",
                    MozTransition: "transitionend",
                    OTransition: "oTransitionEnd otransitionend",
                    transition: "transitionend"
                },
                c;
            for (c in b)
                if (void 0 !== a.style[c]) return b[c];
            return !1
        }();
    A.test = function(a) {
        return O.test(a)
    };
    h.version = "@VERSION";
    h.options = c.proxy(r, h, y);
    h.handlers = c.proxy(r, h, y.handlers);
    h.current = D;
    c(n).on("click.lity", "[data-lity]", h);
    return h
});