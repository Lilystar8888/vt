function calact(nxtact) {
    var nowact = $("#calendar>.active").index();
    //console.log('nowact',nowact);
    $("#calendar li").eq(nowact).removeClass("active");
    $("#calendar li").eq(nxtact).addClass("active");
}

var count = 3;
var today_act = $("#calendar>.today").index();
var left_pos = ["0%", "-57%", "-157.143%", "-257.143%", "-357.143%", "-457.143%", "-500%"];
var left_act = [0, 4, 11, today_act, 25, 32, 35];

function calroll(count) {
    $("#calendar").animate({ "left": left_pos[count] }, "fast");
    //calact(left_act[count]);
}

//count: 0,1,2
function lastweek() {
    if (count>0) { count -= 1; }
    console.log('count:' + count);
    calroll(count);
    if (4>count) {
        $(".calendar .arrow.pull-right").removeClass("end");
        $(".calendar .arrow.pull-right").click(true);
    }
    if (count === 0) {
        $(".calendar .arrow.pull-left").addClass("end");
        $(".calendar .arrow.pull-left").click(false);
    }
}

//count: 3
function nextweek() {
    if (count<4) { count += 1; }
    console.log('count:' + count);
    if (count<4) {
        calroll(count);
    }
    if(count>=3){
        $(".calendar .arrow.pull-right").addClass("end");
        $(".calendar .arrow.pull-right").click(false);
    }else{
        $(".calendar .arrow.pull-left").removeClass("end");
        $(".calendar .arrow.pull-left").click(true);
    }
}

$(document).ready(function() {
    if (!isMobile.any()) {
        $("#calendar").animate({ "left": left_pos[3] }, "fast");
    }
});