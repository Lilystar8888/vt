var isMobile = {Android: function() { return navigator.userAgent.match(/Android/i) }, BlackBerry: function() { return navigator.userAgent.match(/BlackBerry/i) }, iOS: function() { return navigator.userAgent.match(/iPhone|iPad|iPod/i) }, Opera: function() { return navigator.userAgent.match(/Opera Mini/i) }, Windows: function() { return navigator.userAgent.match(/IEMobile/i) }, any: function() { return isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows() } };

//点叉叉关闭登入视窗
function hideLogin() {
    $(".login-panel").addClass("hide").removeClass("show"),
    $('#loginBox-panel').remove();
}

//点叉叉关闭登出视窗
function hideLogout() {
    $(".exit-login").addClass("hide").removeClass("show"),
    $('#logoutBox-panel').remove();
}

//启动验证码程序
var imgAr = [
    "/livesport/web/base/js/captcha3/001.jpg",
    "/livesport/web/base/js/captcha3/002.jpg",
    "/livesport/web/base/js/captcha3/003.jpg",
    "/livesport/web/base/js/captcha3/004.jpg",
    "/livesport/web/base/js/captcha3/005.jpg",
    "/livesport/web/base/js/captcha3/006.jpg",
    "/livesport/web/base/js/captcha3/007.jpg",
    "/livesport/web/base/js/captcha3/008.jpg",
    "/livesport/web/base/js/captcha3/009.jpg",
    "/livesport/web/base/js/captcha3/010.jpg",
    "/livesport/web/base/js/captcha3/011.jpg",
    "/livesport/web/base/js/captcha3/012.jpg",
    "/livesport/web/base/js/captcha3/013.jpg",
    "/livesport/web/base/js/captcha3/014.jpg",
    "/livesport/web/base/js/captcha3/015.jpg"
];

function VerityInit() {
    jigsaw.init({
        el: document.getElementById('captcha'),
        onSuccess: function() {
            //202006验证成功
            document.getElementById('msg').innerHTML = '<i class="iconfont icon-icosucceed"></i> Verification successful！',
                document.getElementById('msg').classList.remove("hide")

        },
        onFail: cleanMsg,
        onRefresh: cleanMsg
    })

    function cleanMsg() {
        document.getElementById('msg').innerHTML = '',
            document.getElementById('msg').classList.add("hide")
    }
}

//验证
function goLogin() {
    //是否已完成滑块验证
    var errMsg = "please complete the verification!";
    !$(".sliderContainer").hasClass('sliderContainer_success') ? (
        $("#msg")
        .html('<i class="iconfont icon-error"></i>' + errMsg)
        .removeClass("hide")
    ) : (
        $("#msg, .login-area").addClass("hide"),
        $(".login-ok").removeClass("hide"),
        window.location.href="/livesport/web/back2/index.html"
    )
}
//点登入按钮写入登入视窗 RWD特别版本 请注意已经拿掉style="border-radius: 10px; margin-left: -240px; margin-top: -270px;"
function LoginDialogue() {
    //202006英文版本
    $("body").append('<div id="loginBox-panel"class="util-dialog"style="display: block;"><div class="mask"></div><div class="util-dialog-cda pop login-panel fixed show"><i class="iconfont icon-close"onclick="hideLogin();"></i><div id="login"class="login-area"><div class="title">Login</div><div class="row row-tow"><div class="text-box"><input class="text w-290"id="username"name="username"type="text"placeholder="Email"></div></div><div class="row row-tow"><div class="text-box m-t-16"><input class="text w-290"id="password"name="password"type="password"placeholder="Password (6-30 characters)"></div></div><div class="row row-tow"><a class="link float-right f-s-12 color-bbb m-t-12 m-b-12"href="forgot-password.html">Forgot your password?</a></div><div class="varea"><div id="captcha"></div></div><div id="msg"class="row row-tow error-msg m-t-10 hide"><i class="icon-error"></i>Verification successful</div><div class="row row-tow m-t-16"><a class="button btn-border active submit line-h-40 w-290"onclick="goLogin()">Login</a></div><div class="row row-tow checkbox-area"><label class="checkbox"onclick="LoginCheck(this)"><span class="check"><input type="checkbox"name="remember"value="1"id="checks"></span>Remember Me (1 Month)</label><a class="link float-right f-s-12 color-de1e30"target="_blank"href="/livesport/web/base/signup.html">sign up</a></div></div><!--登录成功自动跳转到登录前页面--><div class="login-ok hide"><div class="forms-ok"><div class="iconwrap"><i class="iconfont icon-icosucceed"></i></div><div class="title-one">Login successful</div><div class="title-tow countdown"></div></div></div></div></div>');
    VerityInit();
}

//点登出按钮写入登出视窗 RWD特别版本 请注意已经拿掉style="border-radius: 10px; margin-left: -150px; margin-top: -200px;"
function LogoutDialogue() {
    //202006英文版本
    $("body").append('<div id="logoutBox-panel"class="util-dialog"style="display: block;"><div class="mask"></div><div class="util-dialog-cda alt exit-login fixed show"><i class="iconfont icon-close"onclick="hideLogout();"></i><div class="dialog-title">Hint</div><div class="dialog-content center">Click confirm to log out</div><div class="dialog-buttons"><div class="dialog-button "style="width: 150px;"onclick="hideLogout();">Cancel</div><div class="dialog-button primary bd-l"style="width: 149px;"onclick="hideLogout();">Confirm</div></div></div></div>');
}

//发送验证码按钮变色
function sendVcode(e){
    $(e).addClass("active");
}

//国码选单
function initNationCode() {

    //显示隐藏国码选单
    $("#nationcode").click(function() {
        $(".nationlist").toggleClass('hide');
    });

    // 显示隐藏国码选单
    $("#nationcode")
    .mouseenter(function() {
        $(".nationlist").removeClass('hide');
    })
    .mouseleave(function() {
        $(".nationlist").addClass('hide');
    })

    // 点击变换国码後自動關閉選單
    $(".nationlist>li").click(function(e) {
        let prvnation = $("#nationcode").attr('class');
        let nxtnation = $(this).attr('class');
        let thiscode = $(this).find('span').text();
        $(this).addClass("active").siblings("li").removeClass("active"),
            $("#nationcode").removeClass(prvnation).addClass(nxtnation),
            $('#nationcodeinput').attr('value', thiscode);
        $(e).parent('ul').addClass('hide');
    });
}

//手机版主选单开关 登入视窗验证码 登出视窗
$(document).ready(function() {
    //手机版主选单开关 20191025
    $(".navbar a.icon").click(function(e) {
        e.stopPropagation();
        $(window).scrollTop(0);
        $(".navbar.navbar-default").toggleClass("responsive");
        $("body").toggleClass("fixed");
    });
});
