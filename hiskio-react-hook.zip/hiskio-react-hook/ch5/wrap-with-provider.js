import React from 'react';
import AuthProvider from './src/components/Context/AuthProvider';
import CartProvider from './src/components/Context/CartProvider';

import {FavProvider} from './src/components/Fav';

// eslint-disable-next-line import/prefer-default-export
export default ({element}) => (
  <AuthProvider>
    <FavProvider>
      <CartProvider>{element}</CartProvider>
    </FavProvider>
  </AuthProvider>
);
