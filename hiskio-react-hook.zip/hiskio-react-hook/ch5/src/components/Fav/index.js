import React from 'react';

const InitContextValue = {
  favList: ['19f14ec4-959f-495d-9fa8-bca93bfd15f0'],
  add: () => 0,
  remove: () => 0,
};

const FavContext = React.createContext(InitContextValue);

function FavProvider(props) {
  const [favList, dispatch] = React.useReducer(
    controlFavContext,
    InitContextValue.favList,
  );

  const add = id => dispatch({type: 'ADD', id});
  const remove = id => dispatch({type: 'REMOVE', id});

  return (
    <FavContext.Provider value={{favList, add, remove}}>
      {props.children}
    </FavContext.Provider>
  );
}

function controlFavContext(state, action) {
  switch (action.type) {
    case 'ADD':
      if (state.indexOf(action.id) !== -1) {
        return state;
      }

      return [...state, action.id];
    case 'REMOVE':
      if (state.indexOf(action.id) === -1) {
        return state;
      } else {
        let newState = [...state];
        newState.splice(newState.indexOf(action.id), 1);
        return newState;
      }
    default:
      return state;
  }
}

function useFav() {
  const {favList, add, remove} = React.useContext(FavContext);

  const isInFavList = id => favList.indexOf(id) !== -1;
  const toggleFav = id => (isInFavList(id) ? remove(id) : add(id));

  return {isInFavList, toggleFav};
}

export {FavContext, InitContextValue, FavProvider, useFav};
