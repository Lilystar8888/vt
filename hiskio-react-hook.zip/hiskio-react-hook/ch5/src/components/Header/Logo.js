import React from 'react';
import moltin from '../../images/app-logo.png';

const Logo = () => (
  <img src={moltin} style={{width: 60, height: 60}} alt="HiEC" />
);

export default Logo;
