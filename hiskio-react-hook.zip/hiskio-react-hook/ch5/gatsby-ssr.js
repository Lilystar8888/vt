import wrapWithProvider from './wrap-with-provider';

// eslint-disable-next-line import/prefer-default-export
export const wrapRootElement = wrapWithProvider;
