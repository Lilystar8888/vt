import React from "react";
import logo from "./logo.svg";
import "./App.css";

const imgUrl =
  "https://www.revtel.tech/static/c9ae836574b8fae8f80a5dd4b266200e/9f108/revtel-office.png";

class App extends React.Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>

          <Effect>
            {(onClick, hide) => (
              <div
                style={{
                  width: 200,
                  height: 100,
                  marginTop: 10,
                  backgroundColor: "lightgrey",
                }}
                onClick={onClick}
              >
                {!hide && "Button Text"}
              </div>
            )}
          </Effect>

          <Effect>
            {(onClick, hide) => (
              <img
                src={!hide && imgUrl}
                style={{ width: 200, marginTop: 10 }}
                onClick={onClick}
              />
            )}
          </Effect>
        </header>
      </div>
    );
  }
}

class Effect extends React.Component {
  state = {
    clickCount: 0,
  };

  render() {
    let { clickCount } = this.state;

    let onClick = () => {
      if (clickCount === 0) {
        alert("hello hiskio");
      }
      this.setState({ clickCount: clickCount + 1 });
    };
    return this.props.children(onClick, clickCount > 1);
  }
}

export default App;
