import React from "react";
import logo from "./logo.svg";
import "./App.css";

const imgUrl =
  "https://www.revtel.tech/static/c9ae836574b8fae8f80a5dd4b266200e/9f108/revtel-office.png";

class App extends React.Component {
  state = {
    clickCount: 0,
  };
  render() {
    let { clickCount } = this.state;
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>

          <div
            style={{
              width: 200,
              height: 100,
              marginTop: 10,
              backgroundColor: "lightgrey",
            }}
            onClick={() =>
              onClick(
                () => this.setState({ clickCount: clickCount + 1 }),
                clickCount
              )
            }
          >
            {clickCount <= 1 && 'Button Text'}
          </div>
          <img src={(clickCount <= 1) && imgUrl} style={{ width: 200, marginTop: 10 }} onClick={() =>
              onClick(
                () => this.setState({ clickCount: clickCount + 1 }),
                clickCount
              )
            }/>
        </header>
      </div>
    );
  }
}

function onClick(addOne, num) {
  if (num === 0) {
    alert('hello hiskio')
  }
  addOne()
}

export default App;
