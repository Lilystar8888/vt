import React from 'react'
import logo from './logo.svg';
import './App.css';

const imgUrl = 'https://www.revtel.tech/static/c9ae836574b8fae8f80a5dd4b266200e/9f108/revtel-office.png'

class App extends React.Component {
    render() {
              return (
                <div className="App">
                  <header className="App-header">
                    <img src={logo} className="App-logo" alt="logo" />
                    <p>
                      Edit <code>src/App.js</code> and save to reload.
                    </p>
                    <a
                      className="App-link"
                      href="https://reactjs.org"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Learn React
                    </a>

                    <div style={{width:200, height:100, marginTop:10, backgroundColor:'lightgrey'}}>Button Text</div>
                    <img src={imgUrl} style={{width:200, marginTop:10}} />


                  </header>
                </div>
              );
    }
}



export default App;
