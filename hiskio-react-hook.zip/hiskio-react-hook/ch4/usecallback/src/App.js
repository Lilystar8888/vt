import logo from './logo.svg';
import './App.css';
import React from 'react';


function App() {
  const [age, setAge] = React.useState(30)
  const [salary, setSalary] = React.useState(22000)

  const addAge = React.useCallback(() => setAge(age + 1), [age])
  const addSalary = React.useCallback(() => setSalary(salary + 1000), [salary])

  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />

          <p> coolman info :  age = {age}, salary = {salary}  </p>

          <p onClick={addAge}>add age</p>
          <p onClick={addSalary}>add salary</p>

          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
  )
}

export default App;
