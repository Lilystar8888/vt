import logo from './logo.svg';
import './App.css';
import React, { Children } from 'react';


function App() {
  const chRef = React.useRef(null)

  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          

          <div style={{backgroundColor:'yellow', padding: 20}}>
            <ChildrenComp ref={chRef} />

            <p style={{color:'black'}} onClick={() => {
              chRef.current.addOne()
            }}>parent want to add one</p>
          </div>

          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
  )
}

// --------------------------- //
function ChildrenComp(props, ref) {
  const [counter, setCounter] = React.useState(0)

  const addOne = () => setCounter(counter+1)

  React.useImperativeHandle(ref, () => ({addOne}))
 
  return (
    <div style={{backgroundColor:'lightgrey'}}>
      <p>{counter}</p>
      <p onClick={() => setCounter(counter+1)}>add one</p>
    </div>
  )
}

ChildrenComp = React.forwardRef(ChildrenComp)


export default App;
