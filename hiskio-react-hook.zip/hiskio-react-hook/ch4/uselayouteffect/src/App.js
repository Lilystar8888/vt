import logo from './logo.svg';
import './App.css';
import React, { useEffect } from 'react';


function App() {
  const [title, setTitle] = React.useState('hello world !!!!!!!!!!')

  React.useLayoutEffect(() => {
    let i = 0;
    while (i < 100000000) {
      i++
    }
    setTitle('hello world')
  }, [])

  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />

          {title}
          
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
  )
}



export default App;
