import logo from './logo.svg';
import './App.css';
import React from 'react';


function App() {
  const [num, setNumber] = React.useState(100)
  const [forceUpdateNum, setForceUpdate] = React.useState(0)

  const totalValue = React.useMemo(() =>  {
    let ret = 0
    for(let i = 0 ; i < num; i++) {
      ret += i
    }
    return ret
  }, [num])

 /*

  const totalValue = (() => {
    let ret = 0
    for(let i = 0 ; i < num; i++) {
      ret += i
    }
    return ret
  })()

  */


  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />


          sum(0, {num}) = {totalValue}


          <p onClick={() => setNumber(num+100)}> add 1 to num</p>
          <p onClick={() => setForceUpdate(forceUpdateNum+1)}> update </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
  )
}

export default App;
