import logo from './logo.svg';
import './App.css';
import React from 'react';


function useCurrentTime(date) {
  const [t, setT] = React.useState(date)
  React.useDebugValue(t, t => new Date(t))
  return [t, setT]
}


function App() {
  const [counter, setCounter] = React.useState(0)
  const [counter2, setCounter2] = React.useState(0)

  const [time, setTime] = useCurrentTime(Date.now())


  React.useDebugValue(counter, c => c+'!!!')

  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p onClick={() => setCounter(counter+1)}> {counter}</p>
          <p onClick={() => setCounter2(counter2+1)}> {counter2}</p>
          <button onClick={() => setTime(Date.now())}>click me {time}</button>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
  )
}


export default App;
