import logo from './logo.svg';
import './App.css';
import React, { Children } from 'react';


function App() {

  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          

          <CounterContext.Provider value={{counter: 0}}>
            <MyChildren />
          </CounterContext.Provider>

          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
  )
}

function MyChildren() {
  const counterContext = React.useContext(CounterContext)
  const {counter} = counterContext

  return (
     <p style={{color:'red'}}>{counter}</p>
  )

    // -------- //

  return (
    <CounterContext.Consumer >
      {({counter}) => <p style={{color:'red'}}>{counter}</p>}
    </CounterContext.Consumer>
  )
}

// --------------- //

const CounterContext = React.createContext();



export default App;
