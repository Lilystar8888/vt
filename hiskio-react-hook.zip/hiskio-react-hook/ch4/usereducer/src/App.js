import logo from './logo.svg';
import './App.css';
import React from 'react';


function BalanceReducder(balance, action) {
  switch(action) {
    case 'deposit 10':
      return balance + 10
    case 'withdraw 10':
      if (balance - 10 < 0)
        return 0
      else
        return balance - 10
    default:
      return balance
  }
}


function App() {
  const [balance, balanceDispatch] = React.useReducer(BalanceReducder, 100)

  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />

          <p> account balance = {balance}</p>

          <p onClick={() => balanceDispatch('deposit 10')}> deposit 10</p>
          <p onClick={() => balanceDispatch('withdraw 10')}> withdraw 10</p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
  )
// ---------------------------- //

/*
  const [balance, setBalance] = React.useState(100)

  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />

          <p> account balance = {balance}</p>

          <p onClick={() => setBalance(balance + 10)}> deposit 10</p>
          <p onClick={() => setBalance(balance - 10)}> withdraw 10</p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
  )
  */
}

export default App;
