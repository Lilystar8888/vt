<template>
  <div>
{{this.$store.state.test_data}}
    <CourseList></CourseList>
  </div>
</template>

<script>
import CourseList from '~/components/CourseList/CourseList.vue'
import {mapMutations} from "vuex"

export default {
  data(){
    return {
      title:"",
      message: ""
    }
  },
  created(){
    if(process.client){
      //this.$store.dispatch("ajaxTest");
      //this.$store.dispatch(_M.REMOVE_DATA)
      console.log(this.$store)
      
//      this.add_test_data({
//        title: "test"
//      })
//      this.add_test_data({
//        title: "test"
//      })
//      this.add_test_data({
//        title: "test"
//      })
//      this.$store.commit("add_test_data",{
//        title: "test"
//      })
      
//      this.$store.commit("add_test_data",{
//        title: "test"
//      })
      
    }
    //console.log(this.$store.state.test_data);
    //console.log(this.$store.state);
    //console.log(this.$store.getters);
    //console.log(this.$store.getters[_M.SET_CONFIG_URL]);
  },
  methods:{
    ...mapMutations([
      "add_test_data"
    ])
  },
  computed:{
    get_aaa(){
      return this.$store.getters.get_aaa
    } 
  },
  components: {
    CourseList,
  }
}
</script>
