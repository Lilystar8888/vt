import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _859347ec = () => interopDefault(import('../pages/demo.vue' /* webpackChunkName: "pages/demo" */))
const _5ecc330d = () => interopDefault(import('../pages/demo/index.vue' /* webpackChunkName: "pages/demo/index" */))
const _540e33c2 = () => interopDefault(import('../pages/demo/mock.vue' /* webpackChunkName: "pages/demo/mock" */))
const _393b196b = () => interopDefault(import('../pages/demo/tpl.vue' /* webpackChunkName: "pages/demo/tpl" */))
const _832c7f72 = () => interopDefault(import('../pages/demo/vuex.vue' /* webpackChunkName: "pages/demo/vuex" */))
const _4ff8a02c = () => interopDefault(import('../pages/demo/_test.vue' /* webpackChunkName: "pages/demo/_test" */))
const _4b7341c9 = () => interopDefault(import('../pages/user/favorite.vue' /* webpackChunkName: "pages/user/favorite" */))
const _6ceed1a6 = () => interopDefault(import('../pages/course/_id.vue' /* webpackChunkName: "pages/course/_id" */))
const _e6c1218a = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/demo",
    component: _859347ec,
    children: [{
      path: "",
      component: _5ecc330d,
      name: "demo"
    }, {
      path: "mock",
      component: _540e33c2,
      name: "demo-mock"
    }, {
      path: "tpl",
      component: _393b196b,
      name: "demo-tpl"
    }, {
      path: "vuex",
      component: _832c7f72,
      name: "demo-vuex"
    }, {
      path: ":test",
      component: _4ff8a02c,
      name: "demo-test"
    }]
  }, {
    path: "/user/favorite",
    component: _4b7341c9,
    name: "user-favorite"
  }, {
    path: "/course/:id?",
    component: _6ceed1a6,
    name: "course-id"
  }, {
    path: "/",
    component: _e6c1218a,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
