<template>
  <div>
    <div>這是 demo 模版</div>
    <nuxt />
  </div>
</template>


