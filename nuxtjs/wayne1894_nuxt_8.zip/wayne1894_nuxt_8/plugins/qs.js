import Vue from 'vue'
import Qs from 'qs';

Vue.prototype.$qs = Qs;
