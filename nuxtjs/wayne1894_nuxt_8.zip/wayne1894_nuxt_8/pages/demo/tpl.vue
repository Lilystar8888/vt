<template>
  <div>
    {{infoTest}}
    <Demo message="demotest">
      <div>我是從父組件傳來的</div>
    </Demo>
    <Demo @wayne="wayne_fn" />
    <Logo />
    <img class="box" src="@/assets/img/demo.png" alt="">
    <img src="@/assets/img/demo.svg" alt="">
    <h1>
      {{title}}
    </h1>
    <h2>
      {{h2}}
    </h2>
    <h2 @click="demoFn">
      {{demoH2}}
    </h2>
    <a href="/">wayne1894</a>
    <nuxt-link to="/demo/tpl">到 demo/tpl 頁</nuxt-link> 
    <nuxt-link to="/">回首頁</nuxt-link>
    <datepicker></datepicker>
  </div>
</template>

<script>
import Logo from '~/components/Logo.vue'
import {sleep,deepCopy} from "@/assets/js/tool.js"
import test from "~/assets/js/test.js"
import Demo from "~/components/Demo.vue"
  
export default {
  layout: 'demo',
  head () {
      return {
        title: this.title,
        meta: [
          { hid: 'description', name: 'description', content: 'My custom description' }
        ],
      script:
        [
          { src: "https://cdnjs.cloudflare.com/ajax/libs/gsap/3.2.4/gsap.min.js" }
        ]
      }
  },
  data () {
    return {
      title: "demo",
      h2: "這是 h2",
      infoTest:0
    }
  },
  created(){
//    this.$router.push('/demo/test');
//    console.log(test.test1())
    console.log("我是 tpl.vue");
  },
  mounted(){
//    this.$axios.get("http://localhost:3013/demo/tpl").then((response)=>{
//        console.log(response.data)
//    })
//
//    this.$gsap.to("img", {rotation: 27, x: 100, duration: 1});
//   
    console.log("mounted");
  },
  computed: {
    demoH2(){
      return this.h2 + "(computed)"
    }
  },
  methods: {
    demoFn() {
      console.log("demoFn")
    },
    wayne_fn(info){
      this.infoTest = this.infoTest + info
      console.log(info)
    }
  },
  components: {
    Logo,
    Demo
  }
}
</script>

<style lang="scss" scoped>
/*scoped*/
@import '~/assets/scss/demo.scss';
.example {
    display: grid;
    transition: all .5s;
    user-select: none;
    background: linear-gradient(to bottom, white, black);
}
  h2{
    display: none;
  }
</style>
