<template>
  <img src="~/assets/img/logo.png" alt="">
</template>
<style>

</style>
