//Index
export const SET_CONFIG_URL = "SET_CONFIG_URL";

// Permission
export const GET_PERMISSION = "GET_PERMISSION";
export const DEFAULT_PAGE = "DEFAULT_PAGE";

// Globals
export const SET_LOADING = "SET_LOADING";
export const REMOVE_DATA = "REMOVE_DATA";

// Login
export const SET_LOGIN_STATUS = "SET_LOGIN_STATUS";
export const LOGIN = "LOGIN";
export const LOGOUT = "LOGOUT";
export const GET_USER_NAME = "GET_USER_NAME";
export const GET_ACCOUNTID = "GET_ACCOUNTID";
export const GET_ACCOUNTTPYE = "GET_ACCOUNTTPYE";
