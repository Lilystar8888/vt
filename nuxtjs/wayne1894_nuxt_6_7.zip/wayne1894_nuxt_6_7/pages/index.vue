<template>
  <div>
    <CourseList :courses=this.get_courses></CourseList>
  </div>
</template>

<script>
import CourseList from '~/components/CourseList/CourseList.vue'
import API from '~/api.js'
  
export default {
  fetch(context){
    //代表重新整理，courses 沒有資料
    if(!context.store.state.courses.length){
      return context.store.dispatch("setCoursesList")
    }
  },
  async asyncData (context) { //打ajax (async await)

  },
  data(){
    return {
      title:"",
      message:""
    }
  },
  created(){
   if(process.client){
     
      console.log("process.client")
    }
   if(process.server){
      console.log("process.server");
    }

  },
  computed:{
    get_courses(){
      return this.$store.state.courses
    },
  },
  components: {
    CourseList,
  }
}
</script>
