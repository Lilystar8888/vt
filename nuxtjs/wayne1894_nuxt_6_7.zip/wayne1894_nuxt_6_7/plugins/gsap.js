import Vue from 'vue'
import gsap from "gsap";

Vue.prototype.$gsap = gsap
