function test1(name) {
   return name;
}
function test2(name) {
   return name;
}
//export default {
//    test1,
//    test2
//};
export default test1

