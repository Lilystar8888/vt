<template>
  <div>
    <Header title="wayne1894 教學網"></Header>
    <nuxt />
    <LoginModal @loginModalSubmit="loginModalSubmit" modalTyple="registered" :openModal=true ></LoginModal>
    <Footer></Footer>
  </div>
</template>
<script>
import Header from '~/components/Header/Header.vue'
import Footer from '~/components/Footer/Footer.vue'
import LoginModal from '~/components/Modal/LoginModal.vue'
  
export default {
  methods:{
    loginModalSubmit(data){
      console.log(data,"data")
    }
  },
  components: {
    Header,
    Footer,
    LoginModal
  }
}
</script>
<style>

</style>
