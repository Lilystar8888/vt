<template>
  <div>
    {{message}}
    <Logo @click.native="emit_test"></Logo>
    <div >test</div>
    <slot>我是預設資訊</slot>
  </div>
</template>
<script>
  import Logo from "~/components/Logo.vue"
  export default {
    props:["message"],
    methods:{
      emit_test(){
        this.$emit('wayne',55);
      },
    },
    components:{
      Logo
    }
  }
</script>
<style>

</style>