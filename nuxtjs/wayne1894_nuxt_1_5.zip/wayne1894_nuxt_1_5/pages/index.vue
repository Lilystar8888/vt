<template>
  <div>
    <CourseList :courses=this.get_courses></CourseList>
  </div>
</template>

<script>
import CourseList from '~/components/CourseList/CourseList.vue'

export default {
  fetch(context){
    return context.$axios("api/courses").then((data)=>{
      context.store.commit("set_courses",{
        ...data.data
      })
    })
  },
  async asyncData (context) { //打ajax (async await)
    
   // return context.error({ statusCode: 500, message: 'Page Error' })

    //console.log(context,"context")
    let data = await context.$axios("/api/test");
    //console.log(data,"data.data")
    return data.data
  },
  data(){
    return {
      title:"",
      message:""
    }
  },
  created(){
    
   //this.$nuxt.error({ statusCode: 500, message: '~~~Post not found' })
    
   if(process.client){
     
//      this.$axios("api/courses").then((data)=>{ 
//        this.$store.commit("set_courses",{
//          ...data.data
//        })
//      })

     
     
     
//      this.$axios("/api/test").then((data)=>{
//        this.title = data.data.title;
//        this.message = data.data.message
//        console.log(data.data,"data.data")
//      })
      console.log("process.client")
    }
   if(process.server){
      console.log("process.server");
    }

   console.log(1)
  },
  computed:{
    get_courses(){
      return this.$store.state.courses
    },
  },
  components: {
    CourseList,
  }
}
</script>
